-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2021 at 06:03 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `veerata`
--

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(20) NOT NULL,
  `bankname` varchar(6) NOT NULL,
  `accountno` varchar(11) NOT NULL,
  `ifsc` varchar(11) NOT NULL,
  `amount` varchar(8) NOT NULL,
  `state` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`id`, `username`, `bankname`, `accountno`, `ifsc`, `amount`, `state`) VALUES
(1, 'morkerdeep', 'BOB', '38512312365', 'BOBdeep', '10000', 'Gujarat'),
(2, 'user11', 'HDFC', '10002555863', 'HDFCuser', '50000', 'Goa'),
(3, 'user11', 'HDFC', '10002555863', 'HDFCuser', '15000', 'Goa'),
(4, 'morkerdeep', 'BOB', '38512312365', 'BOBabc', '25000', 'Gujarat'),
(5, 'user11', 'HDFC', '10002563', 'HDFCusers', '101', 'Goa');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `managment_id` int(6) UNSIGNED DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `firstname` varchar(10) NOT NULL,
  `lastname` varchar(10) NOT NULL,
  `email` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL DEFAULT 'other',
  `mobileno` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`managment_id`, `username`, `firstname`, `lastname`, `email`, `password`, `gender`, `mobileno`) VALUES
(1101, 'morkerdeep', 'deep', 'morker', 'morkerdeep', 'Morkerdeep.11', 'male', '9537732425'),
(0, 'user11', 'student', '1', 'user1@gmai', 'Abc.1', 'male', '9865457523');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
